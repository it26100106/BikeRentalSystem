package com.Webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeRentalSystemApplication {
    public static void main(String[] args) {
        SpringApplication.run(BikeRentalSystemApplication.class, args);
    }
}
