package com.Webapp.BikeRentalSystem.service;

import com.Webapp.BikeRentalSystem.dto.ReviewDTO;
import com.Webapp.BikeRentalSystem.filehandling.ReviewFileHandler;
import com.Webapp.BikeRentalSystem.model.Review;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.OptionalDouble;

@Service
public class ReviewService {
    private final ReviewFileHandler reviewFileHandler;
    private final BookingEligibilityService bookingEligibilityService;

    public ReviewService(ReviewFileHandler reviewFileHandler,
                         BookingEligibilityService bookingEligibilityService) {
        this.reviewFileHandler = reviewFileHandler;
        this.bookingEligibilityService = bookingEligibilityService;
    }

    public List<Review> readReviews(String bikeId, String userId) {
        return reviewFileHandler.loadReviews().stream()
                .filter(review -> bikeId == null || bikeId.isBlank() || review.getBikeId().equals(bikeId))
                .filter(review -> userId == null || userId.isBlank() || review.getUserId().equals(userId))
                .sorted(Comparator.comparing(Review::getReviewDate).reversed())
                .toList();
    }

    public OptionalDouble getAverageRating(String bikeId) {
        List<Review> reviews = readReviews(bikeId, null);
        return reviews.isEmpty() ? OptionalDouble.empty()
                : OptionalDouble.of(reviews.stream().mapToInt(Review::getRating).average().orElse(0));
    }

    public synchronized Review createReview(ReviewDTO dto, String userId) {
        requireText(userId, "Please log in before writing a review.");
        validate(dto);
        if (!bookingEligibilityService.hasCompletedBooking(userId, dto.getBikeId())) {
            throw new IllegalArgumentException("A completed booking for this bike is required to write a review.");
        }
        List<Review> reviews = reviewFileHandler.loadReviews();
        if (reviews.stream().anyMatch(review -> review.getUserId().equals(userId)
                && review.getBikeId().equals(dto.getBikeId()))) {
            throw new IllegalArgumentException("You already reviewed this bike. Edit your existing review instead.");
        }
        Review review = new Review(reviewFileHandler.nextId(reviews), userId, dto.getBikeId(), dto.getRating(),
                cleanComment(dto.getComment()), LocalDate.now());
        reviews.add(review);
        reviewFileHandler.saveReviews(reviews);
        return review;
    }

    public synchronized Review updateReview(String reviewId, ReviewDTO dto, String userId) {
        validate(dto);
        List<Review> reviews = reviewFileHandler.loadReviews();
        Review review = ownedReview(reviews, reviewId, userId);
        if (!review.getBikeId().equals(dto.getBikeId())) {
            throw new IllegalArgumentException("A review cannot be moved to another bike.");
        }
        review.setRating(dto.getRating());
        review.setComment(cleanComment(dto.getComment()));
        reviewFileHandler.saveReviews(reviews);
        return review;
    }

    public synchronized void deleteReview(String reviewId, String userId) {
        List<Review> reviews = reviewFileHandler.loadReviews();
        ownedReview(reviews, reviewId, userId);
        reviews.removeIf(review -> review.getReviewId().equals(reviewId));
        reviewFileHandler.saveReviews(reviews);
    }

    private Review ownedReview(List<Review> reviews, String reviewId, String userId) {
        return reviews.stream().filter(review -> review.getReviewId().equals(reviewId))
                .filter(review -> review.getUserId().equals(userId)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Review was not found for this user."));
    }

    private void validate(ReviewDTO dto) {
        if (dto == null) throw new IllegalArgumentException("Review details are required.");
        requireText(dto.getBikeId(), "Bike ID is required.");
        if (dto.getRating() < 1 || dto.getRating() > 5) {
            throw new IllegalArgumentException("Rating must be a whole number from 1 to 5.");
        }
        if (dto.getComment() != null && dto.getComment().length() > 300) {
            throw new IllegalArgumentException("Comment must be 300 characters or fewer.");
        }
    }

    private String cleanComment(String comment) {
        return comment == null ? "" : comment.replace('|', '/').replace('\r', ' ').replace('\n', ' ').trim();
    }

    private void requireText(String value, String message) {
        if (value == null || value.isBlank()) throw new IllegalArgumentException(message);
    }
}
