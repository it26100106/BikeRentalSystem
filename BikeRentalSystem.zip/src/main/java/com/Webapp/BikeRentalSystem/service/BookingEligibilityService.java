package com.Webapp.BikeRentalSystem.service;

import com.Webapp.BikeRentalSystem.filehandling.BookingFileHandler;
import org.springframework.stereotype.Service;

@Service
public class BookingEligibilityService {
    private final BookingFileHandler bookingFileHandler;

    public BookingEligibilityService(BookingFileHandler bookingFileHandler) {
        this.bookingFileHandler = bookingFileHandler;
    }

    public boolean hasCompletedBooking(String userId, String bikeId) {
        return bookingFileHandler.loadBookings().stream().anyMatch(fields ->
                fields[1].equals(userId) && fields[2].equals(bikeId)
                        && "Completed".equalsIgnoreCase(fields[6]));
    }
}
