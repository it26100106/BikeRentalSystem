package com.Webapp.BikeRentalSystem.controller;

import com.Webapp.BikeRentalSystem.dto.ReviewDTO;
import com.Webapp.BikeRentalSystem.model.Review;
import com.Webapp.BikeRentalSystem.service.ReviewService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.OptionalDouble;

@Controller
@RequestMapping("/reviews")
public class ReviewController {
    private final ReviewService reviewService;

    public ReviewController(ReviewService reviewService) {
        this.reviewService = reviewService;
    }

    @GetMapping
    public String reviews(@RequestParam(required = false) String bikeId,
                          @RequestParam(required = false) String userId,
                          @RequestParam(required = false) String filterUserId,
                          @RequestParam(required = false) String error,
                          Model model) {
        List<Review> reviews = reviewService.readReviews(bikeId, filterUserId);
        OptionalDouble average = bikeId == null || bikeId.isBlank()
                ? OptionalDouble.empty() : reviewService.getAverageRating(bikeId);
        model.addAttribute("reviews", reviews);
        model.addAttribute("bikeId", bikeId == null ? "" : bikeId);
        model.addAttribute("userId", userId == null ? "" : userId);
        model.addAttribute("filterUserId", filterUserId == null ? "" : filterUserId);
        model.addAttribute("averageRating", average.isPresent()
                ? String.format("%.1f", average.getAsDouble()) : "No ratings yet");
        model.addAttribute("error", error);
        return "review/reviews";
    }

    @GetMapping("/add")
    public String showAddForm(@RequestParam String bikeId, @RequestParam String userId, Model model) {
        model.addAttribute("reviewDTO", new ReviewDTO(bikeId, 5, ""));
        model.addAttribute("bikeId", bikeId);
        model.addAttribute("userId", userId);
        return "review/addReview";
    }

    @PostMapping("/add")
    public String addReview(@Valid @ModelAttribute("reviewDTO") ReviewDTO dto,
                            BindingResult result,
                            @RequestParam String userId,
                            Model model) {
        if (userId == null || userId.isBlank()) {
            model.addAttribute("bikeId", dto.getBikeId());
            model.addAttribute("userId", "");
            model.addAttribute("formError", "Enter a customer ID before submitting a review.");
            return "review/addReview";
        }
        if (result.hasErrors()) {
            model.addAttribute("bikeId", dto.getBikeId());
            model.addAttribute("userId", userId);
            return "review/addReview";
        }
        try {
            reviewService.createReview(dto, userId);
            return redirect(dto.getBikeId(), userId, null);
        } catch (IllegalArgumentException ex) {
            model.addAttribute("bikeId", dto.getBikeId());
            model.addAttribute("userId", userId);
            model.addAttribute("formError", ex.getMessage());
            return "review/addReview";
        }
    }

    @PostMapping("/{id}/update")
    public String updateReview(@PathVariable String id,
                               @Valid @ModelAttribute("reviewDTO") ReviewDTO dto,
                               BindingResult result,
                               @RequestParam String userId) {
        if (result.hasErrors()) return redirect(dto.getBikeId(), userId, "Review input is invalid.");
        try {
            reviewService.updateReview(id, dto, userId);
            return redirect(dto.getBikeId(), userId, null);
        } catch (IllegalArgumentException ex) {
            return redirect(dto.getBikeId(), userId, ex.getMessage());
        }
    }

    @PostMapping("/{id}/delete")
    public String deleteReview(@PathVariable String id,
                               @RequestParam String bikeId,
                               @RequestParam String userId) {
        try {
            reviewService.deleteReview(id, userId);
            return redirect(bikeId, userId, null);
        } catch (IllegalArgumentException ex) {
            return redirect(bikeId, userId, ex.getMessage());
        }
    }

    private String redirect(String bikeId, String userId, String error) {
        String target = "redirect:/reviews?bikeId=" + encode(bikeId) + "&userId=" + encode(userId);
        return error == null ? target : target + "&error=" + encode(error);
    }

    private String encode(String value) {
        return java.net.URLEncoder.encode(value == null ? "" : value,
                java.nio.charset.StandardCharsets.UTF_8);
    }
}
