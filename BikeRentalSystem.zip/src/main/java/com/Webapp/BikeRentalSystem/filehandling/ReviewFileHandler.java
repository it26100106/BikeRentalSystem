package com.Webapp.BikeRentalSystem.filehandling;

import com.Webapp.BikeRentalSystem.model.Review;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ReviewFileHandler {
    private final FileHandler fileHandler;
    private final String path;

    public ReviewFileHandler(FileHandler fileHandler, @Value("${app.data-dir}") String dataDir) {
        this.fileHandler = fileHandler;
        this.path = dataDir + "/reviews.txt";
    }

    public List<Review> loadReviews() {
        List<Review> reviews = new ArrayList<>();
        for (String line : fileHandler.readLines(path)) reviews.add(Review.fromFileString(line));
        return reviews;
    }

    public void saveReviews(List<Review> reviews) {
        List<String> lines = new ArrayList<>();
        for (Review review : reviews) lines.add(review.toFileString());
        fileHandler.writeLines(path, lines);
    }

    public String nextId(List<Review> reviews) {
        return fileHandler.nextId("RV", reviews.stream().map(Review::getReviewId).toList());
    }
}
