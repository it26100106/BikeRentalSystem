package com.Webapp.BikeRentalSystem.filehandling;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

/** Reads Member 3 booking records for the completed-booking review rule. */
@Component
public class BookingFileHandler {
    private final FileHandler fileHandler;
    private final String path;

    public BookingFileHandler(FileHandler fileHandler, @Value("${app.data-dir}") String dataDir) {
        this.fileHandler = fileHandler;
        this.path = dataDir + "/bookings.txt";
    }

    public List<String[]> loadBookings() {
        return fileHandler.readLines(path).stream()
                .map(line -> line.split("\\|", -1))
                .filter(fields -> fields.length == 7)
                .toList();
    }
}
