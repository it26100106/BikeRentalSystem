package com.Webapp.BikeRentalSystem.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ReviewDTO {
    @NotBlank(message = "Bike ID is required")
    private String bikeId;

    @Min(value = 1, message = "Choose a rating from 1 to 5")
    @Max(value = 5, message = "Choose a rating from 1 to 5")
    private int rating;

    @Size(max = 300, message = "Comment must be 300 characters or fewer")
    private String comment;

    public ReviewDTO() { }
    public ReviewDTO(String bikeId, int rating, String comment) {
        this.bikeId = bikeId;
        this.rating = rating;
        this.comment = comment;
    }
    public String getBikeId() { return bikeId; }
    public void setBikeId(String bikeId) { this.bikeId = bikeId; }
    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
}
